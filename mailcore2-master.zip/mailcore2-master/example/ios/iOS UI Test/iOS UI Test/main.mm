//
//  main.mm
//  iOS UI Test
//
//  Created by Jonathan Willing on 4/8/13.
//  Copyright (c) 2013 AppJon. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"
#import <MailCore/MailCore.h>

int main(int argc, char *argv[]) {
	MCLogEnabled = 1;
	return UIApplicationMain(argc, argv, nil, @"AppDelegate");
}
