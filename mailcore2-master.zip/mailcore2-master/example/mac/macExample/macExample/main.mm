//
//  main.m
//  testUI
//
//  Created by DINH Viêt Hoà on 1/19/13.
//  Copyright (c) 2013 MailCore. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include <MailCore/MailCore.h>

int main(int argc, char *argv[])
{
    //mailcore::setICUDataDirectory(MCSTR("/usr/local/share/icu"));
    return NSApplicationMain(argc, (const char **)argv);
}
