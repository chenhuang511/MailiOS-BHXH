//
//  MCOFramework.h
//  mailcore2
//
//  Created by DINH Viêt Hoà on 4/2/13.
//  Copyright (c) 2013 MailCore. All rights reserved.
//

#import <Foundation/Foundation.h>
